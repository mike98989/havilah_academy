<body class="hold-transition skin-black sidebar-mini" ng-app="sabi">
<base href="<?php echo URL.$url[1];?>/">
<div>
<div class="wrapper">

  <header class="main-header">

    <!-- Logo -->
    <a href="<?php echo URL;?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->

      <span class="logo-mini"><b>Sabi.</b>xyz</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><img src="<?php echo URL;?>public/images/sabi_s_only_logo.png" style="width:20px;margin:-5px 7px 0 0"><b>Sabi.xyz</b></span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->

    </nav>
  </header>

  </div>