        
        <div class="col-md-12" style="display:nne" ng-init="get_categories()">

          <!-- TABLE: LATEST ORDERS -->
          <h3 style="text-align:center">All Categories</h3>
          <div class="box box-success" style="display:nne">
            <div class="box-header with-border">
              <h3 class="box-title">All Categories</h3>
              <a href="{{dirlocation}}adminarea/newcategory" class="btn btn-warning pull-right btn-sm">Add New Category <i class="fa fa-plus"></i></a>
              <div class="box-tools pull-right" style="display:none">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive table-striped table-hover">
                <table class="table no-margin">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Short Description</th>
                    <th>Description</th>
                    <th>Cover</th>
                    <th></th>
                    <th></th>
                    <th></th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr ng-show="categories.length==0">
                    <td colspan="8"><div class="alert alert-default" style="font-weight:bold;text-align:center">No Category Added Yet!</div></td>
                  </tr>
                  <tr ng-show="categories.length!=0" dir-paginate="category in categories | filter: inmateSearch |  itemsPerPage: pageSize" current-page="currentPage" ng-cloak>
                  <td>{{($index +1) + (currentPage-1) * pageSize}}</td>
                    <td><a href="#">{{category.category_title}}</a></td>
                    <td>{{category.category_short_desc}}</td>
                    <td>{{category.category_desc}}</td> 
                    <td><img ng-src="{{dirlocation}}{{category.image_url}}" width="40px"></td> 
                    <td><a href="{{dirlocation}}adminarea/viewcategory?id={{category.category_id}}"><i class="fa fa-eye"></i></a></td>
                    <td><a href="{{dirlocation}}adminarea/editcategory?id={{category.category_id}}"><i class="fa fa-edit"></i></a></td>
                    <td style="color:red;cursor:pointer" ng-click="delete_category(category)"><i class="fa fa-times"></i>
                    <img class="loader_{{category.category_id}}" src="{{dirlocation}}public/images/spinner.gif" style="width:20px;display:none">
                    </td>
                  </tr>
                  
                  </tbody>
                </table>
                <dir-pagination-controls boundary-links="true" template-url="" style="float:right"></dir-pagination-controls>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->