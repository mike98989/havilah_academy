        
        <div class="col-md-12" style="display:nne" ng-init="get_all_books()">

          <!-- TABLE: LATEST ORDERS -->
          <h3 style="text-align:center">All Created Books</h3>
          <div class="box box-success" style="display:nne">
            <div class="box-header with-border">
              <h3 class="box-title">All Books</h3>
              <a href="{{dirlocation}}adminarea/newbook" class="btn btn-warning pull-right btn-sm">Add New Book <i class="fa fa-plus"></i></a>
              <div class="box-tools pull-right" style="display:none">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive table-striped table-hover">
                <table class="table no-margin">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Book Title</th>
                    <th>Author</th>
                    <th>Category</th>
                    <th>Previews</th>
                    <th>Amount</th>
                    <th>Purchases</th>
                    <th>Date Uploaded</th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr dir-paginate="book in books | filter: inmateSearch |  itemsPerPage: pageSize" current-page="currentPage" ng-cloak>
                  <td>{{($index +1) + (currentPage-1) * pageSize}}</td>
                    <td><a href="#">{{book.book_title}}</a></td>
                    <td>{{book.book_author}}</td>
                    <td>{{book.category_title}}</td>
                    <td>{{book.book_view_counter}}</td>           
                    <td>N{{book.book_amount}}</td>
                    <td>{{book.purchases}}</td>
                    <td>{{book.date_created}}</td>
                    <td><img ng-src="{{dirlocation}}{{book.book_cover}}" width="40px"></td> 
                    <td><a href="{{dirlocation}}adminarea/viewbook?book_id={{book.book_id}}"><i class="fa fa-eye"></i></a></td>
                    <td><a href="{{dirlocation}}adminarea/editbook?book_id={{book.book_id}}"><i class="fa fa-edit"></i></a></td>
                    <td ng-click="delete_book(book)" style="color:red;cursor:pointer"><i class="fa fa-times"></i>
                    <img class="loader_{{book.book_id}}" src="{{dirlocation}}public/images/spinner.gif" style="width:20px;display:none"></td>
                  </tr>
                  </tbody>
                </table>
                <dir-pagination-controls boundary-links="true" template-url="" style="float:right"></dir-pagination-controls>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->