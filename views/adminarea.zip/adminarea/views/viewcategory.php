<div ng-init="get_category()">
<div class="col-md-7" style="display:nne">
<div class="box box-success" style="display:nne">
            <div class="box-header with-border">
<h3 style="text-align:center">{{category.category_title}}
<a href="{{dirlocation}}adminarea/editcategory?id={{category.category_id}}" class="btn btn-xs btn-default pull-right">Edit <i class="fa fa-edit"></i></a>
</h3>
<img ng-src="{{dirlocation}}{{category.image_url}}" style="width:100%"/>


<ul class="nav nav-tabs" id="myTab" role="tablist" style="margin-top: 20px">
  <li class="nav-item">
    <a class="nav-link active" id="short_description-tab" data-toggle="tab" href="#short_description" role="tab" aria-controls="short_description" aria-selected="true">Description</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="long_description-tab" data-toggle="tab" href="#long_description" role="tab" aria-controls="long_description" aria-selected="false">Long Description</a>
  </li>

</ul>

<div class="tab-content" id="myTabContent" style="padding:0;">
  <div class="tab-pane active" id="short_description" role="tabpanel" aria-labelledby="short_description-tab" style="padding:5px">
    <p style="" ng-bind-html="category.category_short_desc"></p>
  </div>
  <div class="tab-pane fade" id="long_description" role="tabpanel" aria-labelledby="long_description-tab">
    <p style="" ng-bind-html="category.category_desc"></p>
  </div>
  
</div>

</div>
</div>
</div>

<div class="col-md-5" style="display:nne" ng-init="get_category_books()">
<div class="box box-success" style="display:nne;padding:10px">
<h3 style="text-align:center">Category Books</h3>
<table class="table table-striped table-hover table-condensed">
<tr style="font-weight:bold">
<td>#</td>
<td>Title</td>
<td></td>
</tr>
<tr ng-show="books.length ==0">
<td colspan="3"><div class="alert alert-default" style="text-align:center">No book uploaded yet for this category</div></td>
</tr>
<tr ng-show="books.length!=0" dir-paginate="book in books | filter: inmateSearch |  itemsPerPage: pageSize" current-page="currentPage" ng-cloak>
<td>{{($index +1) + (currentPage-1) * pageSize}}</td>
<td>{{book.book_title}}</td>
<td><img ng-src="{{dirlocation}}{{book.book_cover}}" width="40px"></td>
</tr>
</table>
<dir-pagination-controls boundary-links="true" template-url="" style="float:right"></dir-pagination-controls>
</div>


</div>
</div>