        
        <div class="col-md-12" style="display:nne" ng-init="count_related_tables()">


         <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-book"></i></span>

            <a href="{{dirlocation}}adminarea/books" style="color:inherit">
            <div class="info-box-content">
              <span class="info-box-text">Total Books</span>
              <span class="info-box-number">{{count_records.total_books}}</span>
            </div>
            </a>

            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
          <!-- /.info-box -->

           <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-orange"><i class="fa fa-th"></i></span>

            <a href="{{dirlocation}}adminarea/categories" style="color:inherit">
            <div class="info-box-content">
              <span class="info-box-text">Categories</span>
              <span class="info-box-number">{{count_records.total_categories}}</span>
            </div>
            </a>

            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
          
          
          
        </div>
        <!-- /.col -->