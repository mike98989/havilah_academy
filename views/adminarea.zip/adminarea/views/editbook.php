<div class="col-md-9" style="display:nne" ng-init="get_book_details(); get_categories()">
<div class="box box-success" style="display:nne">
            <div class="box-header with-border">
<form ng-submit="save_book()" class="col-lg-12" id="save_book">
<h3 style="text-align:center">Edit Book {{book.book_title}}</h3>
<div class="loader" style="text-align: center;display:none">
        <img ng-src="{{dirlocation}}public/images/spinner.gif" style="width:50px">
 </div>
 <div class="result alert alert-warning" style="text-align:center;display:none"></div> 
<div class="col-md-6">
<label>Book Title</label>
<input type="text" class="form-control" name="book_title" value="{{book.book_title}}">
<label>Book Category</label>
<select class="form-control" name="book_category" ng-model="book.book_category" required>
<option value="">--SELECT CATEGORY --</option>
<option value="{{category.category_id}}" ng-repeat="category in categories">{{category.category_title}}</option>
</select>
<label>Book Description</label>
<textarea class="form-control" name="book_desc" rows="4">{{book.book_desc}}</textarea>
</div> 
<div class="col-md-6">
<label>Book Author</label>
<input type="text" class="form-control" name="book_author" value="{{book.book_author}}" required>
<label>Book Price Tag (N)</label>
<input type="number" class="form-control" name="book_amount" value="{{book.book_amount}}" required>
<label>Browse Book Cover</label>
<input type="file" onchange="angular.element(this).scope().attach_image(this)" class="form-control" class="form-control" id="book_cover" name="book_cover">
<label>Browse Epub file</label>
<input type="file" class="form-control" name="book_epub_file">
<input type="hidden" value="1" name="status">
<input type="hidden" value="<?php echo date('Y-m-d');?>" name="date_created">
<input type="hidden" value="{{book.book_id}}" name="edit">
<button type="submit" class="btn btn-md btn-success pull-right" style="margin-top:10px">Submit</button>
</div>

</form>

</div>
</div>
</div>

<div class="col-md-3" style="display:nne">
<div class="box box-success" style="display:nne">
<h5 style="text-align:center">Book Cover Image</h5>
<img id="sample_book_cover_img" ng-src="{{dirlocation}}{{book.book_cover}}" style="width:100%"/>
</div>


</div>