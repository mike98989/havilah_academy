<div class="col-md-9" style="display:nne" ng-init="get_category()">
<div class="box box-success" style="display:nne">
            <div class="box-header with-border">
             
<form ng-submit="save_category()" class="col-lg-12" id="save_category">
<h3 style="text-align:center">Edit Category </h3>
<div class="loader" style="text-align: center;display:none">
        <img ng-src="{{dirlocation}}public/images/spinner.gif" style="width:50px">
    </div>
 <div class="result alert alert-warning" style="text-align:center;display:none"></div>   
<div class="col-md-6">
<label>Category Title</label>
<input type="text" class="form-control" name="category_title" required value="{{category.category_title}}">
<label>Book Short Description</label>
<textarea class="form-control" rows="3" name="category_short_desc">{{category.category_short_desc}}</textarea>
</div> 

<div class="col-md-6">
<label>Book Description</label>
<textarea class="form-control" rows="4" name="category_desc">{{category.category_desc}}</textarea>
<label>Browse Book Cover</label>
<input type="file" onchange="angular.element(this).scope().attach_image(this)" class="form-control" name="category_cover">
<input type="hidden" value="1" name="status">
<input type="hidden" value="{{category.category_id}}" name="edit">
<button type="submit" class="btn btn-md btn-success pull-right" style="margin-top:10px">Submit</button>
</div>

</form>

</div>
</div>
</div>

<div class="col-md-3" style="display:nne">
<div class="box box-success" style="display:nne">
<h5 style="text-align:center">Sample Cover Image</h5>
<img id="sample_category_cover_img" style="width:100%" ng-src="{{dirlocation}}{{category.image_url}}" />
</div>


</div>